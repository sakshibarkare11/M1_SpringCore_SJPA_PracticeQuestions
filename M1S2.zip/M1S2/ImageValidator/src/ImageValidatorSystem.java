
public class ImageValidatorSystem {
	public boolean validateImageSize(int imageSize) throws InvalidDataException {
        //fill the code here
		if(imageSize>20) {
			throw new InvalidDataException("Image size exceeds 20KB");
		}else
        return true;
    }

    public boolean validateImageResolution(int width, int height) throws InvalidDataException  {
         //fill the code here
    	if((width*height)>(1024*768)) {
			throw new InvalidDataException("Image Resolution exceeds 1024x768 pixels");

    	}else
        return true;
    }

    public double calculateUploadCost(int imageSize) {
         //fill the code here
    	double amount=0;
    	if(imageSize<=10) {
    		amount=0;
    	}else if(imageSize>10){
    		amount=(imageSize-10)*0.50;
    	}
        return amount;
    }
}
