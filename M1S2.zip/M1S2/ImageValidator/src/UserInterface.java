import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ImageValidatorSystem iv= new ImageValidatorSystem();
       //fill the code here
        System.out.println("Enter the user Name:");
        String name=sc.nextLine();
        System.out.println("Enter the title of Image:");
        String title=sc.nextLine();
        System.out.println("Enter the size of Image (in KB):");
        int size=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the width of Image (in pixels):");
        int width=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the height of Image (in pixels):");
        int height=sc.nextInt();
        sc.nextLine();
        
      
		try {
			 boolean a = iv.validateImageResolution(width, height);
			 boolean b = iv.validateImageSize(size);
			 if(a==true && b==true)
		       {
		    	  double amount= iv.calculateUploadCost(size);
		    	 
		              
		       System.out.println("Thank you for uploading the image");
		 	  System.out.println("Upload  cost: $"+amount);
		 	  }
		} catch (InvalidDataException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
      
    }
}