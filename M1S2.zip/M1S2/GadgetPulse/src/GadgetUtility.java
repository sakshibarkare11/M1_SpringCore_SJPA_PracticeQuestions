import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class GadgetUtility {

    public List<Gadget> retrieveGadgetsByType(Stream<Gadget> gadgetStream, String type) {
    	
        //Fill the code here
        return gadgetStream.filter(n->n.getType().equals(type)).toList();
    }

    public List<Gadget> retrieveGadgetsByManufacturer(Stream<Gadget> gadgetStream, String manufacturer) {
       //Fill the code here
        return gadgetStream.filter(n->n.getManufacturer().equals(manufacturer)).toList();
    }

    public List<Gadget> filterAndSortGadgetsByPrice(Stream<Gadget> gadgetStream) {
        //Fill the code here
        return gadgetStream.sorted(Comparator.comparing(Gadget::getPrice)).toList();
    }
}
