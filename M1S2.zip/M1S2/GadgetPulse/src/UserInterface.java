import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserInterface {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        GadgetUtility gu=new GadgetUtility();

        System.out.println("Enter the total number of gadgets to add to the list");
        int totalGadgets = sc.nextInt();
        sc.nextLine(); 

        List<Gadget> gadgets = new ArrayList<>();

        System.out.println("Enter the gadget details (name,type,manufacturer,price)");
        for(int i=0;i<totalGadgets;i++) {
        	String str=sc.nextLine();
        	String splits[]=str.split(",");
        	double price = Double.parseDouble(splits[3]);
        	Gadget gd=new Gadget(splits[0],splits[1],splits[2],price);
        	gadgets.add(gd);
        }
        
        System.out.println("Enter the gadget type");
        String gadgettype=sc.nextLine();
        List<Gadget> ll=gu.retrieveGadgetsByType(gadgets.stream(), gadgettype);
        if(ll.isEmpty()) {
        	System.out.println("No gadgets founds for the given type");
        }else {
            System.out.println("Gadgets of type "+gadgettype);

        for(Gadget g: ll) {
        	System.out.println(g.getName()+"/"+g.getType()+"/"+g.getManufacturer()+"/"+g.getPrice());
        }
        }
        System.out.println("Enter the gadget manufacturer");
        String manufacturer=sc.nextLine();
        List<Gadget> al=gu.retrieveGadgetsByManufacturer(gadgets.stream(), manufacturer);
        if(al.isEmpty()) {
        	System.out.println("No gadgets founds for the given manufacturer");
        }else {
            System.out.println("Gadgets by "+manufacturer);

        for(Gadget g: al) {
        	System.out.println(g.getName()+"/"+g.getType()+"/"+g.getManufacturer()+"/"+g.getPrice());
        }}
        // Get the gadget details and add it to the List
        
        // Write the code to - Retrieve gadgets by type
        
        // Write the code to - Retrieve gadgets by manufacturer
        
        // Write the code to - Filter and sort gadgets by price
        
    }
}
