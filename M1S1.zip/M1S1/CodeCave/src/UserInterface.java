import java.util.List;
import java.util.Scanner;

public class UserInterface {
	public static void main(String args[])
	{
	    Scanner sc=new Scanner(System.in);
	    TrainerInfo tInfo=new TrainerInfo();
	    
	    
	    //Fill the code
	    System.out.println("Enter number of records to be added");
	    int num=sc.nextInt();
	    sc.nextLine();
	    System.out.println("Enter the trainer records (Trainer id : Performance rating)");
	    for(int i=0;i<num;i++) {
	    	String str=sc.nextLine();
	    	String splits[]=str.split(":");
	    	String s1=splits[0];
	    	Float rating=Float.parseFloat(splits[1]);
	    	tInfo.addTrainerDetails(s1,rating );
	    }
	    System.out.println("Enter the trainer id to be searched ");
	    String search=sc.nextLine();
	   float p= tInfo.findPerformanceRatingOfGivenTrainerId(search);
	   if(p==-1.0) {
		   System.out.println(search+" is an invalid trainer id");
		
	   }
	   else {
	  System.out.println("Performance rating of trainer id "+search+" is "+p);
	   }
	  List<String> ll=tInfo.findTrainerIdsWithLowPerformanceRating();
	  if(ll.isEmpty()) {
		  System.out.println("No trainers have a low rating");
		  return;
	  }
	    System.out.println("Trainer id of the trainers with low rating are ");
	   
//	    if(ll.isEmpty()) {
//	    	System.out.println("No trainers have low rating");
//	    	return;
//	    }
	 
	    for(String s:ll) {
	    	System.out.println(s);
	    }
	    
		System.out.println();
	}
	
}