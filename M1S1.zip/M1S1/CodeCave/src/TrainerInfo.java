import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrainerInfo {
    
    private Map<String, Float> trainerMap = new HashMap<>();
    
    public Map<String, Float> getTrainerMap() {
        return trainerMap;
    }

    public void setTrainerMap(Map<String, Float> trainerMap) {
        this.trainerMap = trainerMap;
    }

    public void addTrainerDetails(String trainerId, float performanceRating) {
	    //Fill the code
	    trainerMap.put(trainerId, performanceRating);
    }

    public float findPerformanceRatingOfGivenTrainerId(String trainerId) {
	    //Fill the code
    	for(Map.Entry<String, Float>  entry:trainerMap.entrySet()) {
    		if(entry.getKey().equals(trainerId)) {
    			return entry.getValue();
    		}
    	}
	
	    return -1;
    }

    public List<String> findTrainerIdsWithLowPerformanceRating() {
      	//Fill the code
      	List<String> lRating=new ArrayList<>();
      	for(Map.Entry<String, Float>  entry:trainerMap.entrySet()) {
    		if(entry.getValue()<=3) {
    		lRating.add(entry.getKey());
    		}
	 
    }
		return lRating;
}
}