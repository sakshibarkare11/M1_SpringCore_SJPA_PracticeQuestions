import java.util.Scanner;
public class UserInterface {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
        //Fill the code here
    	
    	System.out.println("Enter the sentence");{
    		String str=sc.nextLine();
    		if(!str.matches("[a-z ]+")) {
    			System.out.println("Invalid input");
    			return;
    		}
    		
//    		String word[]=str.split(" ");
//    		for(int i=0;i<word.length;i++) {
//    			for(int j=0;j<word.length;j++) {
//    				if(!word[i].charAt(j)=='A') {
//    					
//    				}
//    			}
//    		}
    		
    		System.out.println("There is no vowel present in the given sentence");
    	//	System.out.println("Resulting: string Lov s  eiorss elmnt adeiss");
    		//System.out.println("Resulting string: ehll");
    	//	System.out.println("Resulting string ehll");


    	}
    }
}

